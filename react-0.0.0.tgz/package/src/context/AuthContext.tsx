import { createContext } from "react";

export const Authcontext = createContext(null);