
export default function Login() {
    return   (
                <div className="flex item-center justify-center h-screen">
                    <div className="p-6 bg-white shadow rounded w-80">
                        <h2 className="text-xl font-bold mb-4">
                            Login
                        </h2>
                        <input className="border p-2 w-full mb-3" 
                        placeholder="Email"
                        /><br></br><br></br>
                        <input className="border p-2 w-full mb-3" 
                        placeholder="Password"
                        /><br></br><br></br>
                        <button className="bg-blue-500 text-white w-full p-2">
                           Login 
                        </button>

                    </div>
                </div>
             );
}
