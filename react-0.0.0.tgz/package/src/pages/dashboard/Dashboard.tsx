export default function Dashboard() {
     return  (
               <div className="p-6">
                  <h1 className="text-2xl font-bold">
                     Dashboard
                  </h1>
                  <div className="grid grid-cols-3 gap-4 mt-6">
                      <div className="p-4 bg-white shadow">
                          Income
                      </div>
                      <div className="p-4 bg-white shadow">
                          Expences
                      </div>
                      <div className="p-4 bg-white shadow">
                          Balance
                      </div>
                  </div>
               </div>
             )
}