export default function Settings() {
    return  (
               <h1 className="p-6 text-xl">
                  Settings Page
               </h1>
            )
}