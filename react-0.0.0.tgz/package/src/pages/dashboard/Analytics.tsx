export default function Analytics() {
    return  (
               <h1 className="p-6 text-xl">
                  Analytics Page
               </h1>
            )
}