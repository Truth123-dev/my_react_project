export default function About() {
    return  (
               <h1 className="p-6 text-xl">
                  About  Page
               </h1>
            )
}