export default function Home() {
    return  (
               <h1 className="p-6 text-xl">
                  Home Page
               </h1>
            )
}