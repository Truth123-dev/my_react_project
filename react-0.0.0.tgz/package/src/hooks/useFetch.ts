import { useState, useEffect } from "react";
import { getUser } from "../services/api";

type User = {
    id: number;
    name: string;
};
export function useFetchUser() {
            const [users, setUsers] = useState<User[]>([]);

    useEffect(() => {
        getUser().then((data) => setUsers(data));
    }, []);

    return users;
}