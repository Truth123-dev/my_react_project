// import Counter from "./components/counter";
// import Todo from "./components/todo";
import Apicontrol from "./components/Apicontrol";

// import "./index";

function App() {
    return (
        <div>
            <Apicontrol />
        </div>
    )
    // <Todo />
    // return    (

    //             <div className="app">
    //               <Counter />

    //             </div>
    //          )  
}
export default App;