export const getUser = () => {
    return  Promise.resolve([

        { id:1, name: "John"},
        { id:2, name: "Isaiah"},
        { id:3, name: "Elijah"},
        { id:4, name: "Zara"},
        { id:5, name: "Joe"}
    ]);
};