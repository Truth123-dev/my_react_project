export default function Card({ title }: { title:

 string }) {
    return  (
               <div  className="p-4 bg-white shadow rounded">
                  {title}
               </div>
            );
}