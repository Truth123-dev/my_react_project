import  { useEffect , useState} from "react";
import "./ApiUser.css";


interface User {
    id: number;
    name: string;
    email: string; 
    phone: string;
    website: string;
}

function  ApiUsers() {
      const [users, setUsers ] = useState<User[]>([]);
      const [loading, setLoading ] = useState<boolean>(true);
      const [error, setError ] = useState<string | null>(null);
     
    useEffect(() => {
        const fetchUsers = async () => {
            try{
                setLoading(true);
                setError(null);

                const response = await fetch(
                    "https://jsonplaceholder.typicode.com/users"
                );

                if (!response.ok) {
                   throw new Error ("Failed to fecth users");
                }

                const data: User[] = await response.json();
                setUsers(data);
            } catch (error){
               if (error instanceof Error) {
                setError(error.message)
               } else {
                setError("Something went wrong");
               }
            } finally {
                setLoading(false);
            }
        };
        fetchUsers();
    }, []);


    if (loading) {
      return (
        <div className="center">
             <div className="loader"></div>
             <p>Loading Users...</p>
        </div>
      );
    }

    if (error) {
    return (
        <div className="center-error">
            <h1>
                Error
            </h1>
            <p>{error}</p>
        </div>
    );
  }  

  return (
    <div className="container">
        <h1 className="title">
           User Directory
        </h1>

        <div className="grid">
           {useState.length === 0 ? (
            <p>No users found.</p>
           ) : (
            users.map((user) => (
              <div key={user.id} className="card">
                   <h2>  {user.name}</h2>
                   <h2>  {user.email}</h2>
                   <h2>  {user.phone}</h2>
                   <h2>  {user.website}</h2>
              </div>
            ))
           )}
        </div>
    </div>
  );
}
export default ApiUsers;
  