export default function Navbar() {
    return   (
                <div className="p-4 bg-gray-800 text-white flex 
                justify-between">
                    <h1>
                       My app
                    </h1>
                    <div>
                       Menu
                    </div>
                </div>  
             )
}