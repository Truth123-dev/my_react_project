
import { useState } from "react";

function Counter() {
    const [ count, setCount ] = useState<number>(0);

    const increase  = () => {
        setCount(count + 1);
    };

    const decrease  = () => {
        setCount(count - 1);
    };
    const reset = () => {
        setCount(0);
    };

    return (
        <div className="counter">
            <h1>
                Counter App
            </h1>
            <h1>
                { count }
            </h1>
            <div className="buttons">
               <button onClick={increase}>
                  Increase
               </button>

                <button onClick={decrease}>
                  decrease
               </button>

                <button onClick={reset}>
                  Reset
               </button>

            </div>
        </div>
    );
}
export default Counter;