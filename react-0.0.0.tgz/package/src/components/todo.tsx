import { useState } from "react";
import "./App.css";



interface TodoItem{
    id: number;
    text: string;
}

function Todo() {
    const [input , setInput] = useState("");
    const [todos , setTodos] = useState<TodoItem[]>([]);
 
  const addTodo = () => {
    if (!input.trim()) return;

    const newTodo = {
        id: Date.now(),
        text: input,
    };

    setTodos([...todos, newTodo]);
    setInput("");      
    
  };

  const deleteTodo = (id: number) => {
    setTodos(
        todos.filter((todo) =>  todo.id !== id)
    );
  };

  return  (
             <div className="todo-container">
                 <h2>
                    Todo App
                 </h2>
                 <div className="todo-input-group">
                    <input  
                     value={input}
                     onChange={(e) =>
                        setInput(e.target.value)
                     }
                     placeholder="Enter a tasks...."
                  />

                  <button 
                      className="add-btn"
                      onClick={addTodo}
                      >
                       Add
                  </button>
                 </div>
                
                  {todos.map((todo) => (
                    <div 
                        key={todo.id}
                        className="todo-item"
                        >
                        <span className="todo-text">
                            { todo.text }
                        </span>    
                      
                        <button 
                            className="delete-btn"
                            onClick={() =>
                            deleteTodo(todo.id)
                        }
                        >
                          Delete
                        </button>
                    </div>
                  ))}
             </div>
           );
}
export default Todo;